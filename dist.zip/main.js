function createElement(tagName, attrs = {}, ...children) {
  const elem = Object.assign(document.createElement(tagName), attrs);

  for (const child of children) {
    if (Array.isArray(child)) elem.append(...child);else elem.append(child);
  }

  return elem;
}

define(['base/js/namespace', 'base/js/events'], function (Jupyter, events) {
  var add_cell = function () {
    Jupyter.notebook.insert_cell_above('code').set_text(``);
    Jupyter.notebook.select_prev();
    Jupyter.notebook.execute_cell_and_select_below();
  };

  var defaultCellButton = function () {
    Jupyter.toolbar.add_buttons_group([Jupyter.keyboard_manager.actions.register({
      'help': 'Add default cell',
      'icon': 'fa-play-circle',
      'handler': add_cell
    }, 'add-default-cell', 'Default cell')]);
  };

  function extract_cell_data() {
    let cell = Jupyter.notebook.get_selected_cell();
    alert(cell.get_text());
  }

  const Clippy = createElement("div", {
    className: "root"
  }, createElement("div", {
    className: "chatbox"
  }, "Hello! Do you need help with your code?", createElement("button", {
    id: "help_btn"
  }, "Help me")), createElement("img", {
    src: "/nbextensions/clippy/clippy.png",
    alt: "clippy"
  }), createElement("style", {
    jsx: true
  }, `
                  .root {
                    position: fixed;
                    bottom: 50vh;
                    right: 0;
                    width: 10vw;
                    height: auto;
                    z-index: 100;
                  }

                  .root img {
                    width: 10vw;
                    height: auto;
                  }

                  .root div.chatbox {
                    position: relative;
                    height: auto;
                    width: 10vw;
                    padding: 5px;
                    background-color: #f8f88d;
                  }
                `));

  function load_ipython_extension() {
    document.getElementById("notebook").prepend(Clippy);
    document.getElementById("help_btn").addEventListener("click", extract_cell_data);
  }

  return {
    load_ipython_extension: load_ipython_extension
  };
});